﻿
drop table playerplayedgames;
drop table playersavedgames;
drop table savedposition;
drop table games;
drop trigger testref on players;
drop function insertdata();
drop table authorities;
drop table players;

drop sequence hibernate_sequence; 