package ttt.model.dao;

import java.util.List;

import ttt.model.SavedPosition;

public interface SavedPositionDao {

	List<SavedPosition>  getPosition(int gameid);
	SavedPosition SavePositions(SavedPosition s);
	boolean deleteRecord(int sid);
}
